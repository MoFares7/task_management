package com.example.task_management_fares

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
