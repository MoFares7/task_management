class User {
  final String? email;
  final String? password;
  final String? token;
  final String? error;

  User(
{
      this.email,
      this.password,
      this.token,
      this.error
      });
}
