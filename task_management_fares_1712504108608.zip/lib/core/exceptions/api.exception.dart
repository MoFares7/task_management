enum ApiException {
  usernameAndEmailDuplicated,
  usernameDuplicated,
  emailDuplicated,
  networkError,
  unknownError,
  serverError,
  validationError,
}
