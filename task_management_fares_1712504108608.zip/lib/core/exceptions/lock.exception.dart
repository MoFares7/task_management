enum LockException {
  changeNameException,
  changeSoundException,
  changeLocationException,
}
