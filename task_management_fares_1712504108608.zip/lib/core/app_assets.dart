class AppAssets {
  // Jpg
  static const String user = 'assets/images/user.jpg';

  // SVGs
  static const String errorSvg = 'assets/svg/error.svg';
  static const String noDataSvg = 'assets/svg/no_data.svg';
}
